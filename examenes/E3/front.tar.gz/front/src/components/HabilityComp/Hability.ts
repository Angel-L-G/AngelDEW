export interface Hability {
    title: string;
    description: string;
    color: string;
    icon: Array<String>;
}