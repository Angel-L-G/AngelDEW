export interface Experience {
    title: string;
    duration: string;
    description: string;
    email: string;
}  