export interface Project {
    title: string;
    body: string;
    link: string;
}