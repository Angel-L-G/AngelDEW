<template>
    <div class="container">
        <div class="text-center mt-5">
            <img src="@/assets/profile.jpeg" alt="Mi foto" class="rounded-circle" style="width: 150px; height: 150px;">
            <h2 class="mt-3">{{ $t("profile.greeting") }}</h2>
            <p>{{ $t("profile.profession") }}</p>
        </div>
    </div>
</template>